# Electricity-billing-System
A DBMS project for 4th Sem

# Overview
So basically it an Java UI and MySQl DB project for solving the probelm to pay electricity Bills

# How to Run

First import the zip file.

We have provided the code for creating data tables for SQL in the file "SQL TABLE".

After connecting with MySQL open the project. Check the connection link in Conn.java file.

Run the Login.java file as the Main file. First sign up as an "Admin" and then login using those credentials.

You can then create new customers in which "Meter Number" will be provided and you can fill other details such as address. 
As ADMIN you can check consumer details and you have to insert the units consumed for the specific meter number.


As an Consumer you will be provided the "METER NUMBER" with that you can create your credentials. You have option to update your details such as address and phone number. Your monthly bill will be displayed and you have the option to pay bill online and generating the bill.

# ScreenShots

![image](https://user-images.githubusercontent.com/56160262/117764740-9dd15d80-b24a-11eb-854e-f80c106d99a5.png)
![image](https://user-images.githubusercontent.com/56160262/117764815-b2adf100-b24a-11eb-8606-c0c5957d0873.png)
![image](https://user-images.githubusercontent.com/56160262/117764904-d113ec80-b24a-11eb-954e-05acc0003ba6.png)
